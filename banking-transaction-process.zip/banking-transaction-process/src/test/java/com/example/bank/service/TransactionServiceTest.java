package com.example.bank.service;


import com.example.bank.repositories.LedgerRepository;
import com.example.bank.services.TransactionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class TransactionServiceTest {

    private TransactionService service;

    @BeforeEach
    void setUp() {
        service = new TransactionService(new LedgerRepository());
        service.createAccount("A1");
        service.createAccount("A2");
    }

    @Test
    void deposit_adds_money_to_account() {
        service.deposit("A1", BigDecimal.valueOf(300));

        assertEquals(BigDecimal.valueOf(300), service.balance("A1"));
    }

    @Test
    void withdraw_removes_money_from_account() {
        service.deposit("A1", BigDecimal.valueOf(500));

        service.withdraw("A1", BigDecimal.valueOf(200));

        assertEquals(BigDecimal.valueOf(300), service.balance("A1"));
    }

    @Test
    void transfer_moves_money_between_accounts() {
        service.deposit("A1", BigDecimal.valueOf(500));

        service.transfer("A1", "A2", BigDecimal.valueOf(200));

        assertEquals(BigDecimal.valueOf(300), service.balance("A1"));
        assertEquals(BigDecimal.valueOf(200), service.balance("A2"));
    }

    @Test
    void transfer_fails_when_insufficient_balance() {
        IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> service.transfer("A1", "A2", BigDecimal.valueOf(100))
        );

        assertEquals("Insufficient balance", exception.getMessage());
    }

    @Test
    void transfer_to_same_account_is_not_allowed() {
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> service.transfer("A1", "A1", BigDecimal.valueOf(50))
        );

        assertEquals("Cannot transfer to same account", exception.getMessage());
    }
}
