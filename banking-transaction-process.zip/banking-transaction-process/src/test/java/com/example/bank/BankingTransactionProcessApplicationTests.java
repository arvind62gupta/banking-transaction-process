package com.example.bank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingTransactionProcessApplicationTests {

	@Test
	void contextLoads() {
	}

}
