package com.example.bank.model;


import com.example.bank.models.Account;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class AccountTest {

    @Test
    void deposit_increases_balance() {
        Account account = new Account("A1");

        account.deposit(BigDecimal.valueOf(100));

        assertEquals(BigDecimal.valueOf(100), account.getBalance());
    }

    @Test
    void withdraw_decreases_balance() {
        Account account = new Account("A1");
        account.deposit(BigDecimal.valueOf(200));

        account.withdraw(BigDecimal.valueOf(50));

        assertEquals(BigDecimal.valueOf(150), account.getBalance());
    }

    @Test
    void withdraw_fails_when_insufficient_balance() {
        Account account = new Account("A1");

        IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> account.withdraw(BigDecimal.valueOf(100))
        );

        assertEquals("Insufficient balance", exception.getMessage());
    }

    @Test
    void invalid_amount_is_rejected() {
        Account account = new Account("A1");

        assertThrows(IllegalArgumentException.class,
                () -> account.deposit(BigDecimal.ZERO));
    }
}
