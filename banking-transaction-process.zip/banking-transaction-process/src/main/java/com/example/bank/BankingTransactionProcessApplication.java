package com.example.bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingTransactionProcessApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingTransactionProcessApplication.class, args);
	}

}
