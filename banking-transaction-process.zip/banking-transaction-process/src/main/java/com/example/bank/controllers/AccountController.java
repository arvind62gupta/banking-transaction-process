package com.example.bank.controllers;



import com.example.bank.models.LedgerEntry;
import com.example.bank.services.TransactionService;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api")
public class AccountController {

    private final TransactionService service;

    public AccountController(TransactionService service) {
        this.service = service;
    }

    @PostMapping("/accounts/{id}")
    public void create(@PathVariable String id) {
        service.createAccount(id);
    }

    @GetMapping("/accounts/{id}/balance")
    public BigDecimal balance(@PathVariable String id) {
        return service.balance(id);
    }

    @PostMapping("/accounts/{id}/deposit")
    public void deposit(@PathVariable String id,
                        @RequestParam BigDecimal amount) {
        service.deposit(id, amount);
    }

    @PostMapping("/accounts/{id}/withdraw")
    public void withdraw(@PathVariable String id,
                         @RequestParam BigDecimal amount) {
        service.withdraw(id, amount);
    }

    @PostMapping("/transfer")
    public void transfer(@RequestParam String from,
                         @RequestParam String to,
                         @RequestParam BigDecimal amount) {
        service.transfer(from, to, amount);
    }

    @GetMapping("/ledger/{id}")
    public List<LedgerEntry> ledger(@PathVariable String id) {
        return service.history(id);
    }
}
