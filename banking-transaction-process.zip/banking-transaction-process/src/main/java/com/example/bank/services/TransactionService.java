package com.example.bank.services;


import com.example.bank.models.Account;
import com.example.bank.models.LedgerEntry;
import com.example.bank.models.TransactionType;
import com.example.bank.repositories.LedgerRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class TransactionService {

    private final Map<String, Account> accounts = new HashMap<>();
    private final LedgerRepository ledger;

    public TransactionService(LedgerRepository ledger) {
        this.ledger = ledger;
    }

    public void createAccount(String id) {
        accounts.put(id, new Account(id));
    }

    public BigDecimal balance(String id) {
        return getAccount(id).getBalance();
    }

    public void deposit(String id, BigDecimal amount) {
        Account a = getAccount(id);
        a.deposit(amount);
        ledger.save(new LedgerEntry(id, TransactionType.DEPOSIT, amount));
    }

    public void withdraw(String id, BigDecimal amount) {
        Account a = getAccount(id);
        a.withdraw(amount);
        ledger.save(new LedgerEntry(id, TransactionType.WITHDRAWAL, amount));
    }

    public void transfer(String from, String to, BigDecimal amount) {
        if (from.equals(to)) {
            throw new IllegalArgumentException("Cannot transfer to same account");
        }
        Account source = getAccount(from);
        Account target = getAccount(to);

        source.withdraw(amount);
        target.deposit(amount);

        ledger.save(new LedgerEntry(from, TransactionType.TRANSFER_OUT, amount));
        ledger.save(new LedgerEntry(to, TransactionType.TRANSFER_IN, amount));
    }

    public List<LedgerEntry> history(String id) {
        return ledger.findByAccount(id);
    }

    private Account getAccount(String id) {
        Account account = accounts.get(id);
        if (account == null) {
            throw new IllegalArgumentException("Account not found: " + id);
        }
        return account;
    }
}

