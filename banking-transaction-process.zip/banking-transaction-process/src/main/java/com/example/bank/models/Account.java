package com.example.bank.models;

import java.math.BigDecimal;

public class Account {

    private final String id;
    private BigDecimal balance = BigDecimal.ZERO;

    public Account(String id) {
        this.id = id;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void deposit(BigDecimal amount) {
        validate(amount);
        balance = balance.add(amount);
    }

    public void withdraw(BigDecimal amount) {
        validate(amount);
        if (balance.compareTo(amount) < 0) {
            throw new IllegalStateException("Insufficient balance");
        }
        balance = balance.subtract(amount);
    }

    private void validate(BigDecimal amount) {
        if (amount == null || amount.signum() <= 0) {
            throw new IllegalArgumentException("Amount must be greater than zero");
        }
    }
}