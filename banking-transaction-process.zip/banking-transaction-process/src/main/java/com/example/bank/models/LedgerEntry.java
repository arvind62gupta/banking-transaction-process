package com.example.bank.models;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public class LedgerEntry {

    private final String id = UUID.randomUUID().toString();
    private final String accountId;
    private final TransactionType type;
    private final BigDecimal amount;
    private final Instant timestamp = Instant.now();

    public LedgerEntry(String accountId, TransactionType type, BigDecimal amount) {
        this.accountId = accountId;
        this.type = type;
        this.amount = amount;
    }

    public String getAccountId() { return accountId; }
    public TransactionType getType() { return type; }
    public BigDecimal getAmount() { return amount; }
    public Instant getTimestamp() { return timestamp; }
}
