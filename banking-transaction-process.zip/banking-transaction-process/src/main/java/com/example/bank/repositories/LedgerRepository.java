package com.example.bank.repositories;


import com.example.bank.models.LedgerEntry;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Repository
public class LedgerRepository {

    private final List<LedgerEntry> store = new ArrayList<>();

    public void save(LedgerEntry entry) {
        store.add(entry);
    }

    public List<LedgerEntry> findByAccount(String accountId) {
        return store.stream()
                .filter(e -> e.getAccountId().equals(accountId))
                .collect(Collectors.toList());
    }
}